<---------------------------------------------------->

Version 1.0

Thanks for checking out my first Rimworld mod! This originally started out as a UI based mod, but I found that an immersive research mod was much more fun and interesting.

The main inspirations for this mod are:
Hacking mechanic in Neo Scavenger
'Cryptosleep Revival Briefing' (for lore flavour texts)

!!Important!!
- for some reason, the entire research project list for the current game is only loaded when you open the research window. This is why the research window opens itself when you first load into a game. Blame the original implementation of research mechanics :P.


Main locations to get encrypted datadisks:
	- 5 on pre game start for Classic scenarios (except naked start)
	- Bandit Camp quests
	- Exotic ship traders
	- Exotic caravan traders
	- dismantling mechanoid corpses

In Progress locations:
	- drop pod events
	- more quest rewards
	- raider inventories

Current In Progress Features:
	- More immersive research screen i.e. 'unknown' requirements, hint based instead of direct
	- Mod Settings screen
	- More datadisk spawn locations
	- More flavour texts
	- decryption is performed over time